# kg_web

## 安装依赖
```
cd kg_web
npm install
```

### 运行项目
```
npm run serve
```

### 打包项目
```
npm run build
```