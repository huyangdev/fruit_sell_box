<template>
    <div class="dialog-left">
        <el-row>
            <el-col :span="2" class="di-img">
                <img src="/logo.jpg" width="40" height="40">
            </el-col>
            <el-col :span="22" class="">
                <div class="di-content">
                    {{content}}
                </div>
            </el-col>
        </el-row>
    </div>  
</template>

<script>
export default {
    name:"DialogLeft",
    props:{
        content:String
    }
}
</script>

<style>
    .dialog-left .el-row{
        padding-top: 15px;
    }
    .dialog-left .el-col{
        text-align: left;
    }

    .dialog-left .di-title{
        padding: 8px 0px 2px 6px;
        text-align: left;
    }

    .dialog-left .di-content{
        float: left;
        max-width: 400px;
        word-wrap:break-word; 
        word-break:break-all; 
        overflow: hidden;
        padding: 12px;
        background-color: #fff;
        border-radius: 6px;
    }
    .dialog-left .di-img img{
        border-radius: 25px;
    }
</style>