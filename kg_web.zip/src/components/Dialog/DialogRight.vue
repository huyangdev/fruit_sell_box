<template>
    <div class="dialog-right">
        <el-row>
            <el-col :span="22">
                <div class="di-content">
                    {{content}}
                </div>
            </el-col>
            <el-col :span="2" class="di-img">
                <img src="/logo.jpg" width="40" height="40">
            </el-col>
        </el-row>
    </div>  
</template>

<script>
export default {
    name:"DialogRight",
    props:{
        content:String
    }
}
</script>

<style>
    .dialog-right .el-row{
        padding-top: 15px;
    }
    .dialog-right .el-col{
        text-align: left;
    }

    .dialog-right .di-title{
        padding: 8px 0px 2px 6px;
        text-align: left;
    }

    .dialog-right .di-content{
        float: right;
        max-width: 400px;
        word-wrap:break-word; 
        word-break:break-all; 
        overflow: hidden;
        padding: 12px;
        background-color: rgb(152, 225, 101);
        border-radius: 6px;
    }
    .dialog-right .di-img img{
        border-radius: 25px;
        margin-left: 10px;
    }
</style>