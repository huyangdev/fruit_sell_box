<template>
    <ul id="nav">
        <li>上汽</li>
        <li>江中</li>
        <li>宝隆</li>
    </ul>
</template>

<script>
export default {

}
</script>

<style scoped>
    #nav{
        height: 600px;
        background-color: #545c64;
        color: #fff;
    }
    #nav li{
        padding:10px 5px;
        transition-duration: 0.5s;
    }
    #nav li:hover{
        
        background-color: rgb(67, 74, 80);
        cursor: pointer;
    }
</style>