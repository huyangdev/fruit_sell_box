<template>
  <div id="kg">
      <Header msg="图谱可视化" />
      <div id="mountNode"></div>
  </div>
</template>

<script>
import Header from "@/components/Header/Header.vue"
import G6 from '@antv/g6';
import axios from 'axios';
export default {
    name:"Qa",
    components:{
        Header
    },
    mounted(){
        this.main()
    },
    data(){
        return {
            graph:null,
            remoteData:null,
        }
    },
    methods: {
        refreshDragedNodePosition(e) {
            const model = e.item.get('model');
            model.fx = e.x;
            model.fy = e.y;
        },
        async loadData(){
            const response = await axios('./data.json')
            .then(res => {
                this.remoteData = res.data
                this.remoteData.nodes.forEach(element => {
                    if (!element.style) {
                        element.style = {}
                    }
                    switch(element.class){
                        case 'c1':{
                            element.style.fill = "#ff4e4e"
                            break;
                        }
                        case 'c2':{
                            element.style.fill = "#873bf4"
                            break;
                        }
                        case 'c3':{
                            element.style.fill = "#788fff"
                            break;
                        }
                    }
                });
            })
        },
        async main(){
            this.graph = new G6.Graph({
                container: 'mountNode', // 指定挂载容器
                width: 550, // 图的宽度
                height: 600, // 图的高度
                modes: {
                    default: ['drag-canvas', 'zoom-canvas', 'drag-node'], // 允许拖拽画布、放缩画布、拖拽节点
                },
                layout:{
                    type:"force",
                    preventOverlap: true,
                    linkDistance:200

                },
                // fitView: true, // 是否图适配到画布中
                // fitViewPadding: [20,40.50,20], // 画布的padding
                animate: true, // 启用图的动画
                defaultNode:{
                    size:50,
                    style:{
                        fill: "steelblue",
                        stroke: "#666",
                        lineWidth:1
                    },
                    labelCfg:{
                        style:{
                            fill:"#fff"
                        }
                    }
                },
                defaultEdge:{
                    style:{
                        opacity:0.6,
                        stroke:"grey",
                    },
                    labelCfg: {
                        autoRotate:true // 边上的标签文本， 根据边的方向进行旋转
                    }
                }
            })


            await this.loadData()
            this.graph.data(this.remoteData)
            this.graph.render()
            
            this.graph.on('node:dragstart', (e) => {
                this.graph;
                this.refreshDragedNodePosition(e);
            })

            this.graph.on('node:drag', (e) => {
                const forceLayout = this.graph.get('layoutController').layoutMethods[0];
                forceLayout.execute();
                this.refreshDragedNodePosition(e);
            });
            
            this.graph.on('node:dragend', (e) => {
                e.item.get('model').fx = null;
                e.item.get('model').fy = null;
            });
            const container = document.getElementById('mountNode');
            if (typeof window !== 'undefined')
                window.onresize = () => {
                    if (!this.graph || this.graph.get('destroyed')) return;
                    
                    if (!container || !container.scrollWidth || !container.scrollHeight) return;
                    this.graph.changeSize(container.scrollWidth, container.scrollHeight);
                };
        }
    }
}
</script>

<style>

</style>