<template>
  <h1 class='title' >{{msg}}</h1>
</template>

<script>
export default {
    name:"Header",
    props:{
        msg:String,
    }
}
</script>

<style scoped>
    .title{
        font-size: 20px;
        height: 30px;
        padding:5px 0px;
        background-color: #4e6ef2;
        color:#fff;
    }
</style>