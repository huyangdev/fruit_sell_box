<template>
    <div id="qa">
        <Header msg="智能问答"  />
        <div ref="scrollview" class="dialog" @scroll="scrollChange">
            <DialogLeft content="12313213" />
            <DialogRight content="5555555555555" />
            <div v-for="(item,index) in qaList" :key="index">
                <DialogRight v-if="item.flag" :content="item.data" />
                <DialogLeft v-else :content="item.data" />
            </div>
        </div>
        <div class="input-main">
            <div class="rec">
                <el-button size="small" round>推荐项1</el-button>
                <el-button size="small" round>推荐项2</el-button>
                <el-button size="small" round>推荐项3</el-button>
                <el-button size="small" round>推荐项4</el-button>
                <el-button size="small" round>推荐项5</el-button>
                <!-- <el-button size="small" round>{{scrollTop}}</el-button> -->
            </div>
            <el-input
                v-model="textarea"
                :rows="2"
                type="textarea"
                placeholder="Please input"
                class="di-textarea"
            />
            <div class="submit">
                <el-button @click="send" type="primary">发送</el-button>
            </div>
        </div>
    </div>
</template>

<script>
import Header from "@/components/Header/Header.vue"
import DialogLeft from "@/components/Dialog/DialogLeft.vue"
import DialogRight from "@/components/Dialog/DialogRight.vue"

export default {
    name:"Qa",
    components:{
        Header,
        DialogLeft,
        DialogRight
    },
    data(){
        return {
            textarea:this.scrollTop,
        }
    },
    mounted(){
        // const scrollview = this.$refs["scrollview"]

        // scrollview.addEventListener("scroll", this.scrollChange,true)
    },
    computed:{
      qaList(){
          return this.$store.getters.getDialogList
      }
    },
    methods:{
        send(){
            if(!this.textarea || this.textarea == ""){
                return
            }
            // 存储到dialogList
            console.log(this.textarea)
            this.$store.commit("setDialogList",{flag:1,data:this.textarea})
            
            // 进行意图识别,得到实体名称

            // 将识别出的实体保存到最近访问,作为推荐

            // 封装实体名称,调用后台API,得到结果集

            // 处理结果集(系统回复的内容)

            // 更新图谱
            
            // 清空
            this.textarea = ""

            // 修改滚动条的值
            setTimeout(()=>{
                let qa_box = this.$refs["scrollview"];
                qa_box.scrollTop = qa_box.scrollHeight; 
                console.log(qa_box.scrollHeight)
            },50)

        },
        scrollChange(e){
            console.log("scroll : ", e.target.scrollTop)
        }
    }
}
</script>

<style scoped>

    .dialog{
        height: 400px;
        /* border: 1px solid #000; */
        overflow: hidden;
        overflow-y: auto;
        padding: 0px 5px 10px 5px;
        background-color: #ededed;
    }
    .input-main{
        /* background-color: #ededed; */
    }
    .rec{
        padding: 8px 0px 6px 12px;
        text-align: left;
    }
    .submit{
        margin: 10px 10px 0px 0px;
        text-align: right;
    }
    .el-textarea{
        width:526px
    }

</style>