<template>
  <div class="common-layout">
    <el-row class="main-container">
        <el-col class="nav" :span="2">
          <Nav/>
        </el-col>
        <el-col class="qa-col" :span="11">
          <Qa />
        </el-col>
        <el-col :span="11">
          <Kg />
        </el-col>
    </el-row>
  </div>
</template>

<script>
import Nav from "@/components/Nav/Nav.vue"
import Qa from "@/components/Qa/Qa.vue"
import Kg from "@/components/Kg/Kg.vue"



export default {
  name:"MainLayout",
  components:{
    Nav,
    Qa,
    Kg
  }
}
</script>

<style scoped>
.common-layout{
    width: 1200px;
    height: 700px;
    margin: 50px auto;
}
.el-row {
  margin-bottom: 20px;
}
.el-row:last-child {
  margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
  /* border: 1px solid red; */
  height:600px
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.main-container{
  border-radius: 4px;
  box-shadow: 1px 1px 26px 2px #ccc;
}

.qa-col{
  /* border-left: 2px solid #ccc; */
  border-right: 2px solid #ccc;
}

</style>