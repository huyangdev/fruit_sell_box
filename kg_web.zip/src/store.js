import {createStore} from "vuex"

const stroe = createStore({
    state: {
        count: 123,
        dialogList:[
            {
                flag:0,
                data:`4564656516546816546f6d5s56fsd165f1d65s1f6ds51f6d1 f456ds4f65sd4564f65df4d56s4f6 fdsafds5f46sd54f65sda4f6dsf ds4f6asd4f6d4s6fsd fdsa4f56ds
                fdsa4f56ds
                fdsa4f56ds`
            },
            {
                flag:1,
                data:`4564656516546816546f6d5s56fsd165f1d65s1f6ds51f6d1 f456ds4f65sd4564f65df4d56s4f6 fdsafds5f46sd54f65sda4f6dsf ds4f6asd4f6d4s6fsd fdsa4f56ds
                fdsa4f56ds
                fdsa4f56ds`
            },
            {
                flag:0,
                data:`4564656516546816546f6d5s56fsd165f1d65s1f6ds51f6d1 f456ds4f65sd4564f65df4d56s4f6 fdsafds5f46sd54f65sda4f6dsf ds4f6asd4f6d4s6fsd fdsa4f56ds
                fdsa4f56ds
                fdsa4f56ds`
            },
            {
                flag:1,
                data:`4564656516546816546f6d5s56fsd165f1d65s1f6ds51f6d1 f456ds4f65sd4564f65df4d56s4f6 fdsafds5f46sd54f65sda4f6dsf ds4f6asd4f6d4s6fsd fdsa4f56ds
                fdsa4f56ds
                fdsa4f56ds`
            }
        ]
    },
    getters:{
        count:(state) => {
            return state.count;
        },
        getDialogList:(state) => {
            return state.dialogList
        }
    },
    mutations:{
        setDialogList(state,payload){
            state.dialogList.push(payload)
        }
    }
})
export default stroe