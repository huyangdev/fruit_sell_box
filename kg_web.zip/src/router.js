import { createRouter, createWebHashHistory } from 'vue-router'
// import Index from "./view/list/Index"

import MainLayout from "./views/layout/MainLayout"

const routes = [
  {
    path: '/',
    name: 'MainLayout',
    component: MainLayout
  }
  // {
  //   path: '/about',
  //   name: 'about',
  //   component: () => import('../views/AboutView.vue')
  // }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
